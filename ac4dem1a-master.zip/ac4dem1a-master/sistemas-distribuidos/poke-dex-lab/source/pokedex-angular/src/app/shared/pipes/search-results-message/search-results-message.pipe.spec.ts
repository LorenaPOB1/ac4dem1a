import { SearchResultsMessagePipe } from './search-results-message.pipe';

describe('SearchResultsMessagePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchResultsMessagePipe();
    expect(pipe).toBeTruthy();
  });
});
