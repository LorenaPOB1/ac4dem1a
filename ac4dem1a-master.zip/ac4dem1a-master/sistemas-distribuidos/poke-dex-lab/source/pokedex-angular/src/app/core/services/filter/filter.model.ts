interface FilterModel {
  pokedexVersionId: number;
  pokemonName: string;
  pokemonSortBy: string;
  pokemonTypeId: number;
}

export default FilterModel;
