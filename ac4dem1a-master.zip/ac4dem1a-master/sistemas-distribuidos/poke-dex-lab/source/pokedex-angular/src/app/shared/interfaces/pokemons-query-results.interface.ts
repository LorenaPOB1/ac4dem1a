import PokemonEntity from 'src/app/core/services/pokemon/pokemon.entity';

interface PokemonsQueryResultsInterface {
  pokemon_v2_pokemon: PokemonEntity[];
}

export default PokemonsQueryResultsInterface;
