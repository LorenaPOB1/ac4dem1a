interface PokemonTypeModel {
  id: number;
  name: string;
}

export default PokemonTypeModel;
