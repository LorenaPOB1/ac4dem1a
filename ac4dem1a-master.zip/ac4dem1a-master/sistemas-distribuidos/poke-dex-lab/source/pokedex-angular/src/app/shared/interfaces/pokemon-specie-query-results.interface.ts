import { PokemonSpecieEntity } from 'src/app/core/services/pokemon-specie/pokemon-specie.entity';

interface PokemonSpecieQueryResultsInterface {
  pokemon_v2_pokemonspecies: PokemonSpecieEntity[];
}

export default PokemonSpecieQueryResultsInterface;
